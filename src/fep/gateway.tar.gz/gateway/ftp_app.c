#include <stdlib.h>
#include <stdio.h>
#include    <sys/socket.h>  /* basic socket definitions */
#include    <sys/time.h>    /* timeval{} for select() */
#include    <time.h>        /* timespec{} for pselect() */
#include    <netinet/in.h>
#include    <arpa/inet.h>   /* inet(3) functions */
#include    <errno.h>
#include    <fcntl.h>       /* for nonblocking */
#include    <netdb.h>
#include    <signal.h>
#include    <stdarg.h>
#include   <string.h>
#include   <signal.h>
#include   <stddef.h>
#include <stdarg.h>
#include <assert.h>
#include <ctype.h>
#include <limits.h>
#include <dlfcn.h>
extern gs_run_mode;

	struct CFTPCommand
	{
		int m_nTokenID;
		char *m_pszName;
	};
	enum // Token ID's
	{
		TOK_USER, TOK_PASS, TOK_CWD, TOK_PWD, 
		TOK_PORT, TOK_PASV, TOK_TYPE, TOK_LIST,
		TOK_REST, TOK_CDUP, TOK_RETR, TOK_STOR,
		TOK_SIZE, TOK_DELE, TOK_RMD, TOK_MKD,
		TOK_RNFR, TOK_RNTO, TOK_ABOR, TOK_SYST, TOK_NOOP, 
		TOK_BYE, TOK_QUIT, TOK_ERROR,
	};
struct CFTPCommand commandList[] = 
	{
		{TOK_USER,	"USER"},
		{TOK_PASS,	"PASS"},
		{TOK_CWD,	"CWD"	},
		{TOK_PWD,	"PWD"	},
		{TOK_PORT,	"PORT"},
		{TOK_PASV,	"PASV"},
		{TOK_TYPE,	"TYPE"},
		{TOK_LIST,	"LIST"},
		{TOK_REST,	"REST"},
		{TOK_CDUP,	"CDUP"},
		{TOK_RETR,	"RETR"},
		{TOK_STOR,	"STOR"},
		{TOK_SIZE,	"SIZE"},
		{TOK_DELE,	"DELE"},
		{TOK_RMD,	"RMD"},
		{TOK_MKD,	"MKD"},
		{TOK_RNFR,	"RNFR"},
		{TOK_RNTO,	"RNTO"},
		{TOK_ABOR,	"ABOR"}, 
		{TOK_SYST,	"SYST"},
		{TOK_NOOP,	"NOOP"},
		{TOK_BYE,	"BYE"},
		{TOK_QUIT,	"QUIT"},
		{TOK_ERROR,	""},
	};
struct FD_REC{
	int sockfd;
	time_t  timeout;
	time_t  last_time;
	time_t  begin_time;
	int ndx;
	char ip[16]; /*������·IP */
	int  port;   /*������·�˿ں�*/
	char type; /* 0�ͻ���������·��1 ����˹�����· 2�ͻ��˹�����·*/
	char status[4]; /* 0 ׼��״̬ 1����״̬ 2��Կ����״̬ 3���ݴ���״̬ 4���ݽ������״̬*/
	char used;
	int command;
	int data_len;
	int msg_len;
  char key[17];
	char buf[8192];
};

struct FD_REC gl_fd[FD_SETSIZE];
int role=0,stop=0,crypt_flag=0;
static char logfile[256];
void do_loop();
int connect_sock(int i ,int *max_fd);
fd_set read_set,write_set,error_set;
void _srv_exit( int signo);
 void add_to_set(int fd, fd_set *set, int *max_fd) {
  FD_SET(fd, set);
  if (fd >  *max_fd) {
    *max_fd = (int) fd;
  }
}

typedef void sigfunc_t(int);
sigfunc_t * catch_signal(int sig_no, sigfunc_t *sig_catcher)
{
    //
    //catch a specified signal with the given handler
    //
    
    struct sigaction act, oact;
    
    act.sa_handler = sig_catcher;
    act.sa_flags   = 0;

    //block no signals when this signal is being handled.        
    sigemptyset(&act.sa_mask);

    if(sig_no == SIGALRM || sig_no == SIGUSR1 || sig_no == SIGUSR2)
    {
        #ifdef SA_INTERRUPT        
            act.sa_flags |=  SA_INTERRUPT;    
        #endif        
    }
    else
    {
        #ifdef SA_INTERRUPT        
            act.sa_flags |=  SA_INTERRUPT;    
        #endif        

        //#ifdef SA_RESTART
          // act.sa_flags |=  SA_RESTART;
        //#endif    
    }
    
    if(sigaction(sig_no, &act, &oact) < 0)
        return (sigfunc_t *)0;
    return oact.sa_handler;    
}

//-------------------------------------------------

int catch_all_signals(sigfunc_t *sig_catcher)
{
    int signo;
    
    for(signo=1; signo < NSIG; signo++)
    {
        switch(signo)
        {
            case SIGHUP:             
            case SIGCONT:             
                 catch_signal(signo, SIG_IGN);
                 break;

            case SIGCHLD:
            default:
                 catch_signal(signo,sig_catcher);
                 break;     
        }//switch         
    }//for
    
    return 0;    
}
int tcp_open_server(const char *listen_addr, int listen_port)
{
    //description:
    //this function is called by the server end.
    //before listening on socket waiting for requests
    //from clients, the server should create the socket,
    //then bind its port to it.All is done by this function

    //arguments:
    //listen_addr--IP address or host name of the server,maybe NULL
    //listen_port--port# on which the server listen on

    int   arg=1;
	int on;
    int   sock;
    struct sockaddr_in	sin;
	struct linger linger_str;

    //create the socket
    sock=socket(AF_INET,SOCK_STREAM,0);
    if(sock < 0)
	return -1;

    //get the IP address and port#
    memset(&sin,0,sizeof(struct sockaddr_in));
    sin.sin_family = AF_INET;
    sin.sin_port   = htons(listen_port);

    if(listen_addr == NULL)
        sin.sin_addr.s_addr = htonl(INADDR_ANY);
    else
    {
        int  addr;
				if ((addr=inet_addr(listen_addr)) != INADDR_NONE)
				    sin.sin_addr.s_addr = addr;
				else	//'listen_addr' may be the host name
				{
				    struct hostent *ph;
			
				    ph=gethostbyname(listen_addr);
				    if(!ph)
					goto lblError;
				    sin.sin_addr.s_addr = ((struct in_addr *)ph->h_addr)->s_addr;
				}
    }

    //set option for socket and bind the (IP,port#) with it
    arg=1;
    setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,(char *)&arg,sizeof(arg));
    setsockopt(sock,SOL_SOCKET,SO_KEEPALIVE,(char *)&arg,sizeof(arg));
    

    if(bind(sock,(struct sockaddr *)&sin,sizeof(sin)) < 0)
	     goto lblError;

    //put the socket into passive open status
    if(listen(sock,50) < 0)
	     goto lblError;
    linger_str.l_onoff = 0;
    linger_str.l_linger = 1;
    setsockopt(sock,SOL_SOCKET,SO_LINGER,&linger_str,sizeof(struct linger));
	  on = 1;


    return sock;

lblError:
    if(sock >= 0)
	close(sock);
    return -1;
}
int tcp_connet_server(char *server_addr, int server_port,int client_port)
{
    //this function is performed by the client end to
    //try to establish connection with server in blocking
    //mode

    int    arg, sock, addr,flags;
    struct sockaddr_in	sin;
    struct linger linger_str;

    //the address of server must be presented
    if(server_addr == NULL || server_port == 0)
	return -1;

    //create the socket
    sock=socket(AF_INET,SOCK_STREAM,0);
    if(sock < 0)
	return -1;

    //set option for socket
    arg=1;
    setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,(char *)&arg,sizeof(arg));
    setsockopt(sock,SOL_SOCKET,SO_KEEPALIVE,(char *)&arg,sizeof(arg));
    linger_str.l_onoff = 0;
    linger_str.l_linger = 1;
    setsockopt(sock,SOL_SOCKET,SO_LINGER,&linger_str,sizeof(struct linger));
//    struct timeval tv ;
//    tv.tv_sec = 2;
//    tv.tv_usec = 0;
    
//    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    //if 'client_port' presented,then do a binding
    if(client_port > 0)
    {
       memset(&sin,0,sizeof(struct sockaddr_in));
       sin.sin_family = AF_INET;
       sin.sin_port   = htons(client_port);
       sin.sin_addr.s_addr = htonl(INADDR_ANY);

       arg=1;
       setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,(char *)&arg,sizeof(arg));
       if(0 > bind(sock,(struct sockaddr *)&sin,sizeof(sin)))
             goto lblError;
    }

    //prepare the address of server
    memset(&sin,0,sizeof(struct sockaddr_in));
    sin.sin_family = AF_INET;
    sin.sin_port   = htons(server_port);

    if ((addr=inet_addr(server_addr)) != INADDR_NONE)
	sin.sin_addr.s_addr = addr;
    else  //'server_addr' may be the host name
    {
        struct hostent *ph;
        ph=gethostbyname(server_addr);
        if(!ph)
	    goto lblError;

	sin.sin_addr.s_addr = ((struct in_addr *)ph->h_addr)->s_addr;
    }
   flags=fcntl(sock,F_GETFL);
   fcntl(sock,F_SETFL,flags|O_NDELAY);

    //try to connect to server
 //   if(connect(sock,(struct sockaddr *)&sin,sizeof(sin)) < 0)
 //       goto lblError;
    connect(sock,(struct sockaddr *)&sin,sizeof(sin));
    return sock;

lblError:
    if(sock >= 0)
        close(sock);
    return -1;
}


int main (int argc, char *argv[] )
{
	int i;
	char tmp[32],tmp1[32];

	sprintf(logfile,"%s.log",argv[0]);
	dcs_log_open(logfile,NULL);
	catch_all_signals(_srv_exit);
	catch_signal(40,_srv_exit);
	catch_signal(13,SIG_IGN);
	memset(&gl_fd,0,sizeof sizeof(struct FD_REC)*FD_SETSIZE);
/*
		for ( i=1; i<argc ;i++)
		{
			 if(memcmp("svr_ip",argv[i],6)==0 )
			 {
			 	 if ( strlen( argv[i] ) >6 && atoi(argv[i]+6)>=0)
			 	 {
			 	     sscanf(argv[i],"%*[^=]=%s",g_para[atoi(argv[i]+6)].svr_ip);
			 	     dcs_debug(0,0,"svr_ip%d=%s !\n",atoi(argv[i]+6),g_para[atoi(argv[i]+6)].svr_ip);
			   }
			   else 
			   {
			   	  dcs_log(0,0,"error entry para[%d] =%s",atoi(argv[i]+6),argv[i]);
			   	  return;
			   }
			 }
			 else if(memcmp("svr_port",argv[i],8)==0 )
			 {
			 	  if ( strlen( argv[i] ) >8 && atoi(argv[i]+8)>=0)
			 	  {
			 	  		sscanf(argv[i],"%*[^=]=%d",&g_para[atoi(argv[i]+8)].svr_port);
			 	  		dcs_debug(0,0,"svr_port%d=%d !\n",atoi(argv[i]+8),g_para[atoi(argv[i]+8)].svr_port);
			 	  }
			 	  else 
			   {
			   	  dcs_log(0,0,"error entry para[%d] =%s",atoi(argv[i]+8),argv[i]);
			   	  return;
			   }
			 }
			 else if(memcmp("loc_port",argv[i],8)==0 )
			 {
			 	  if ( strlen( argv[i] ) >8 && atoi(argv[i]+8)>=0)
			 	  {
				 	  sscanf(argv[i],"%*[^=]=%d",&g_para[atoi(argv[i]+8)].loc_port);
				 	  dcs_debug(0,0,"loc_port%d=%d !\n",atoi(argv[i]+8),g_para[atoi(argv[i]+8)].loc_port);
				 	  g_para[atoi(argv[i]+8)].used=0x31;
			 	  }
			 	  else 
			   {
			   	  dcs_log(0,0,"error entry para[%d] =%s",atoi(argv[i]+8),argv[i]);
			   	  return;
			   }
			 }
//			 else if(memcmp("head_len",argv[i],8)==0 )
//			 {
//			 	  
//				 	  sscanf(argv[i],"%*[^=]=%d",&_head_len);
//				 	  dcs_log(0,0,"head_len=%d !\n",_head_len);
//			 }
//			 else if(memcmp("msg_id_flg",argv[i],10)==0 )
//			 {
//			 	  
//				 	  sscanf(argv[i],"%*[^=]=%d",&_msg_id_flg);
//				 	  dcs_log(0,0,"msg_id_flg=%d !\n",_msg_id_flg);
//			 }
//			 else if(memcmp("msg_fld_len_flg",argv[i],15)==0 )
//			 {
//			 	  
//				 	  sscanf(argv[i],"%*[^=]=%d",&_msg_fld_len_flg);
//				 	  dcs_log(0,0,"msg_fld_len_flg=%d !\n",_msg_fld_len_flg);
//			 }
			 else if(memcmp("role",argv[i],4)==0 )
			 {
			 	  sscanf(argv[i],"%*[^=]=%d",&role);
			 	  dcs_debug(0,0,"role=%d !\n",role);
			 }
			 else if(memcmp("crypt_flag",argv[i],10)==0 )
			 {
			 	  sscanf(argv[i],"%*[^=]=%d",&crypt_flag);
			 	  dcs_debug(0,0,"crypt_flag=%d !\n",crypt_flag);
			 }
			 else if(memcmp("type",argv[i],4)==0 )
			 {
			 	  if ( strlen( argv[i] ) >4 && atoi(argv[i]+4)>=0)
			 	  {
			 	    sscanf(argv[i],"%*[^=]=%d",&g_para[atoi(argv[i]+4)].type);
			 	    dcs_debug(0,0,"type%d=%d !\n",atoi(argv[i]+4),g_para[atoi(argv[i]+4)].type);
			 	 }
			 	  else 
			   {
			   	  dcs_log(0,0,"error entry para=%s",argv[i]);
			   	  return;
			   }
			 }
			 else if(memcmp("cfgfile",argv[i],7)==0 )
			 {
			 	  
				 	  sscanf(argv[i],"%*[^=]=%s",cfgfile);
				 	  if ( strlen( argv[i] ) >7 && atoi(argv[i]+7)>=0)
			 	    {
			 	       sscanf(argv[i],"%*[^=]=%s",g_para[atoi(argv[i]+6)].cfgfile);
			 	       dcs_debug(0,0,"cfgfile%d=%s !\n",atoi(argv[i]+6),g_para[atoi(argv[i]+6)].cfgfile);
			 	       iso_mode=1;
			      }
				 	   else 
				   {
				   	  dcs_log(0,0,"error entry para=%s",argv[i]);
				   	  return;
				   }
			 }
			 else if(memcmp("logfile",argv[i],7)==0 )
			 {
			 	  
				 	  sscanf(argv[i],"%*[^=]=%s",logfile);
				 	  dcs_debug(0,0,"logfile=%s !\n",logfile);
				 	  
			 }
			 else if(memcmp("-p",argv[i],2)==0 )
			 {
			 	  
				 	  fprintf(stderr,"\n version 2.0-%s %s release \n",__DATE__,__TIME__);
				 	  return;
			 }
			 else
			 {
			 	    dcs_log(0,0,"error entry para=%s",argv[i]);
			   	  return;
			}
			 
		}
*/	
/* 
  i=tcp_connect_server("128.0.0.1",21,0);
  if( i <0 )
      return dcs_log(0,0,"connect ftp server error[%d][%s]",errno,strerror(errno));
*/  
	do_loop();
	dcs_log_close();
	_srv_exit(0);
	return 1;
}
int tcp_accept_client(int listen_sock,int *client_addr, int *client_port)
{
    struct sockaddr_in cliaddr;
    socklen_t addr_len;
    int    conn_sock;

    for(;;)
    {
        //try accepting a connection request from clients
        addr_len  = sizeof(cliaddr);
        conn_sock = accept(listen_sock, (struct sockaddr *)&cliaddr, &addr_len);

        if(conn_sock >=0)
            break;
        if(conn_sock < 0 && errno == EINTR)
            continue;
        else
            return -1;
    }

    //bring the client info (IP_address, port#) back to caller
    if(client_addr)
        *client_addr = cliaddr.sin_addr.s_addr;
    if(client_port)
        *client_port = ntohs(cliaddr.sin_port);

    return conn_sock;
}



void _srv_exit( int signo)
{
	int i;
	
	if ( signo == 40 )
	{
		  
			if (gs_run_mode)
			{
				dcs_log(0,0,"open log debug mode ! signo=[%d]",signo);
				gs_run_mode=0;
			}
			else
			{
				dcs_log(0,0,"close log debug mode ! signo=[%d]",signo);
				gs_run_mode=1;
			}
			return;
	}
	dcs_log(0,0,"system  exit! signo=[%d]",signo);
	if( signo== 15 )
	{
		 stop=1;
		 return;
	}
	 for ( i=0; i < FD_SETSIZE;i++)
   {
  	 if ( gl_fd[i].used )
  	 {
  	 	 close(gl_fd[i].sockfd);
  	 	 gl_fd[i].used=0;
  	 }
   }
	 exit(0);
}

void do_loop()
{
	
  fd_set vread_set,vwrite_set,verror_set;
  struct timeval tv;
  
  int max_fd ,i ,sock,loc_flg=0,ret,error,len,sl_sock;
  int s,flags,l,vmax_fd=0;
  unsigned char buffer[8192],tmp[256];
 
  loop_init:
  FD_ZERO(&read_set);
  FD_ZERO(&write_set);
  FD_ZERO(&error_set);
  stop =0;
  max_fd=0;
    //������������������˿�
  /*
	  sock=tcp_open_server(NULL, g_para.loc_port);
	  if( sock >0 )
    {
    	add_to_set(sock, &read_set, &max_fd);
    	add_to_set(sock, &error_set, &max_fd);
      gl_fd[0].type=0;
      gl_fd[0].used=1;
      gl_fd[0].data_len=0;
      gl_fd[0].msg_len=0;
      gl_fd[0].sockfd=sock;
      gl_fd[0].status=1;
      dcs_log(0,0,"open local port succ ![%d][%d]\n",g_para.loc_port,sock);
    }
    else
    {
    	 dcs_log(0,0,"open local port fail ![%d][%s]",g_para.loc_port,strerror(errno));
    	 _srv_exit(0);
    		
    }
*/
  gl_fd[0].sockfd=0;
  gl_fd[0].type = 1; //��׼����
  gl_fd[0].used=1;
  strcpy(gl_fd[0].status,"000");
  add_to_set(0, &read_set, &max_fd);
 
 
//    sock=tcp_connet_server("172.16.129.231",21,0);
    sock=tcp_connet_server("127.0.0.1",21,0);
	  if ( sock < 0)
	  {
       dcs_log(0,0,"connect ftp server error[%d]:%s",errno,strerror(errno));
       return;
	  }
	  else
	  {
	  	  dcs_debug(0,0,"connect ftpserver succ! sock=%d ",sock);
	  	  add_to_set(sock, &write_set, &max_fd);
	  	  add_to_set(sock, &error_set, &max_fd);
	  	  gl_fd[sock].sockfd=sock;
        gl_fd[sock].type = 2; //����˹�����·
        gl_fd[sock].used=1;
        strcpy(gl_fd[sock].status,"000");
        sl_sock = sock;
	  }
	  
	  dcs_debug(0,0,"begin entry select while!");
    while(1)
    { 
       
       if ( stop ) break;
    
    	tv.tv_sec = 5;
      tv.tv_usec = 0;
      vread_set=read_set;
      vwrite_set=write_set;
      verror_set=error_set;
//      vmax_fd=0;
//      if ( vmax_fd <max_fd) max_fd=vmax_fd;
    	ret=select(max_fd + 1, &vread_set, &vwrite_set, &verror_set, &tv);
//    	  ret=select(max_fd + 1, &vread_set, NULL, &verror_set, &tv);
//    	fprintf(stderr," recv select event ret=%d !\n",ret);
//      dcs_debug(0,0," recv select event ret=%d !",ret);
      if ( ret < 0) 
    	{
	    	 dcs_log(0,0,"select error![%s],max_fd=%d",strerror(errno),max_fd);
	    
      }
      else if ( ret == 0)
      {
          
           
      } 
      else 
      {
        i=0;
        do{
	        dcs_log(0,0,"select ret=%d",ret);
	    	  if ( gl_fd[i].used )
	    	  {
	          if(FD_ISSET(i, &vread_set))
	    	 	  {
	    	 	  	 ret--;
	    	 	  	   fprintf(stderr,"enter read set proccess!\n"); 
	    	 	  	   if( gl_fd[i].type == 1)
	    	 	  	   {
		    	 	  	 	 int nCommand;
		    	 	  	 	 char *str=NULL;
		    	 	  	 	  dcs_debug(0,0,"recving from sock=[%d],type=[%d]",gl_fd[i].sockfd,gl_fd[i].type);
		    	 	  	 	  len = read(gl_fd[i].sockfd,gl_fd[i].buf,sizeof(gl_fd[i].buf));
		    	 	  	 	  if ( len <=0 )
		    	 	  	 	  {
		    	 	  	 	  	if (len <0)
		    	 	  	 	  	if (errno == EINTR || errno == EAGAIN) goto cri_loop;
		    	 	  	 	  	dcs_log(0,0,"recv server data error![%s]",strerror(errno));
		    	 	  	 	  	FD_CLR(gl_fd[i].sockfd,&read_set);
			    	 	  	 	  FD_CLR(gl_fd[i].sockfd,&error_set);
			    	 	  	 	  close(gl_fd[i].sockfd);
			    	 	  	 	  gl_fd[i].used=0x00;
//			    	 	  	 	  gl_fd[i].status=0x00;
			    	 	  	 	  strcpy(gl_fd[i].status,"000");
	                    goto cri_loop;
		    	 	  	 		}
		    	 	  	 		dcs_log(gl_fd[i].buf,len ,"recv input data len=%d \n",len);
		    	 	  	 		memcpy(buffer,gl_fd[i].buf,len);
		    	 	  	 		buffer[len]=0x00;
//		    	 	  	 		str=strtok(buffer," \n\r");
//		    	 	  	 		fprintf(stderr,"command:%s\n",str);
		    	 	  	 		fprintf(stderr,"stand read:%s",gl_fd[i].buf);
		    	 	  	 		s=0;
		    	 	  	 		
		    	 	  	 		while( 1)
		    	 	  	 		{
		    	 	  	 			if( buffer[s]==0x00 || buffer[s] ==0x20 ||buffer[s]=='\n' ||buffer[s]=='\r' ) break;
		    	 	  	 			if(buffer[s] >='a' && buffer[s]<='z')
		    	 	  	 			    buffer[s]= buffer[s] -0x20;
		    	 	  	 			s++;
		    	 	  	 		}
		    	 	  	 		fprintf(stderr,"command=%s\n",buffer);
		    	 	  	 		buffer[s]=0x00;
		    	 	  	 		for (nCommand = TOK_USER; nCommand < TOK_ERROR; nCommand++)
										{
											// found command ?
											if ( strcmp(buffer, commandList[nCommand].m_pszName)==0)
											{
												break;			
											}
										}
									  fprintf(stderr,"command=%s,%d\n",buffer,nCommand);
										if (nCommand == TOK_ERROR)
										{
											// command is not in our list
											fprintf(stderr,"local:500 Syntax error, command unrecognized.\n");
											goto cri_loop;
//											return;
										}
										gl_fd[sl_sock].command=nCommand;
//										fprintf(stderr,"stand read:%s",gl_fd[i].buf);
		    	 	  	 		write( sl_sock,gl_fd[i].buf,len);
	    	 	  	 	 }
	    	 	  	 	 else if( gl_fd[i].type == 2)
	    	 	  	 	 {
	    	 	  	 	 	  dcs_debug(0,0,"recving from sock=[%d],type=[%d]",gl_fd[i].sockfd,gl_fd[i].type);
		    	 	  	 	  
		    	 	  	 	  len = recv(gl_fd[i].sockfd,gl_fd[i].buf,sizeof(gl_fd[i].buf),0);
		    	 	  	 	  if ( len <=0 )
		    	 	  	 	  {
		    	 	  	 	  	if (len <0)
		    	 	  	 	  	if (errno == EINTR || errno == EAGAIN) goto cri_loop;
		    	 	  	 	  	if (len == 0)
		    	 	  	 	  		dcs_log(0,0,"recv  ftp server data end![%s]",strerror(errno));
		    	 	  	 	  	else
		    	 	  	 	  		dcs_log(0,0,"recv  ftp server data error![%s]",strerror(errno));
		    	 	  	 	  	FD_CLR(gl_fd[i].sockfd,&read_set);
			    	 	  	 	  FD_CLR(gl_fd[i].sockfd,&error_set);
			    	 	  	 	  close(gl_fd[i].sockfd);
			    	 	  	 	  gl_fd[i].used=0x00;
//			    	 	  	 	  gl_fd[i].status=0x00;
	                    goto cri_loop;
		    	 	  	 		}
		    	 	  	 		gl_fd[i].buf[len]=0x00;
		    	 	  	 		dcs_log(gl_fd[i].buf,len ,"recv ftp server data len=%d \n",len);
		    	 	  	 		fprintf(stderr,"%s",gl_fd[i].buf);
		    	 	  	 		memcpy(gl_fd[i].status,gl_fd[i].buf,3);
		    	 	  	 		if( gl_fd[i].command == TOK_PASV )
		    	 	  	 		{
		    	 	  	 			if( memcmp(gl_fd[i].buf,"227",3)==0)
		    	 	  	 			{
		    	 	  	 				int sport;
		    	 	  	 				char *p;
		    	 	  	 				p=strtok(gl_fd[i].buf,",");
		    	 	  	 				p=strtok(NULL,",");
		    	 	  	 				p=strtok(NULL,",");
		    	 	  	 				p=strtok(NULL,",");
		    	 	  	 				p=strtok(NULL,",)");
		    	 	  	 				fprintf(stderr,"first p=%s\n",p);
		    	 	  	 				sport= atoi(p)*256;
		    	 	  	 				p=strtok(NULL,",)");
		    	 	  	 				fprintf(stderr,"second p=%s\n",p);
		    	 	  	 				sport=sport+atoi(p);
		    	 	  	 				fprintf(stderr,"sport=%d\n",sport);
		    	 	  	 				
		    	 	  	 				sock=tcp_connet_server("127.0.0.1",sport,0);
//		    	 	  	 				sock=tcp_connet_server("172.16.129.231",sport,0);
		    	 	  	 				
		    	 	  	 				if( sock > 0)
		    	 	  	 				{
		    	 	  	 					gl_fd[sock].sockfd=sock;
		    	 	  	 					gl_fd[sock].type =3; //���ݴ�����·
		    	 	  	 					add_to_set(sock, &write_set, &max_fd);    	 	  	 					
			    	 	  	 	      add_to_set(sock,&error_set, &max_fd);
			    	 	  	 	      gl_fd[sock].used=1;
			    	 	  	 	      fprintf(stderr,"data link pre connect succ! sock=%d\n",sock); 
		    	 	  	 				}
		    	 	  	 				else
		    	 	  	 				  fprintf(stderr,"data link connect fail!\n"); 
		    	 	  	 					
		    	 	  	 			}
		    	 	  	 		}
	    	 	  	 	 }
	    	 	  	 	 else if( gl_fd[i].type == 3)
	    	 	  	 	 {
	    	 	  	 	 	  dcs_log(0,0,"enter data recv link");
	    	 	  	 	 	  len = read(gl_fd[i].sockfd,gl_fd[i].buf,sizeof(gl_fd[i].buf));
		    	 	  	 	  if ( len <=0 )
		    	 	  	 	  {
		    	 	  	 	  	if (len <0)
		    	 	  	 	  	if (errno == EINTR || errno == EAGAIN) goto cri_loop;
		    	 	  	 	  	if ( len == 0)
		    	 	  	 	  		dcs_log(0,0,"recv  ftp server data end![%s]",strerror(errno));
		    	 	  	 	  	else
		    	 	  	 	  	dcs_log(0,0,"recv  ftp server data error![%s]",strerror(errno));
		    	 	  	 	  	FD_CLR(gl_fd[i].sockfd,&read_set);
			    	 	  	 	  FD_CLR(gl_fd[i].sockfd,&error_set);
			    	 	  	 	  close(gl_fd[i].sockfd);
			    	 	  	 	  gl_fd[i].used=0x00;
//			    	 	  	 	  gl_fd[i].status=0x00;
	                    goto cri_loop;
		    	 	  	 		}
		    	 	  	 		gl_fd[i].buf[len]=0x00;
		    	 	  	 		dcs_log(gl_fd[i].buf,len ,"recv ftp server data len=%d \n",len);
		    	 	  	 		fprintf(stderr,"%s\n",gl_fd[i].buf);
		    	 	  	 		
	    	 	  	 	 }
	    	 	  }
	    	 	  else if(FD_ISSET(i, &vwrite_set))
	    	 	  {
	    	 	  	 ret--;
	    	 	  	 fprintf(stderr,"enter write set proccess!\n");
	    	  		  len=sizeof(error);
	  	 	  	 	  getsockopt(i,SOL_SOCKET,SO_ERROR,&error,&len) ;
	              if( 0 != error )
                { 
                   close(gl_fd[i].sockfd);
	 	  	 	  	     gl_fd[i].used=0x00;
	 	  	 	  	     gl_fd[i].data_len=0;
	 	  	 	  	     gl_fd[i].msg_len=0;
//	 	  	 	  	     gl_fd[i].status=0;	  
	 	  	 	  	     FD_CLR(gl_fd[i].sockfd,&error_set);	 	  	 	         
	 	  	 	         dcs_log(0,0,"  connect server socket error!addr=[%s]:[%d][%s]",gl_fd[i].ip,gl_fd[i].port,strerror(errno));	
	 	  	 	         return;   
                }  
                FD_CLR(i,&write_set);
                add_to_set(sock, &read_set, &max_fd);
	    	 	  }
	    	 	  else if(FD_ISSET(i, &verror_set))
	    	 	  {
	    	 	  	 fprintf(stderr,"enter error set proccess!\n");
	    	 	  	dcs_log(0,0," select error sock i=%d",i);
	    	 	  }
	    	 	}
	    	 	
	    	 	i++;
cri_loop:	    	 	
    	 	;
        }while(ret >0 );
      }
    }

 
  for ( i=0; i < 4;i++)
  {
  	 if ( gl_fd[i].used )
  	 {
  	 	 close(gl_fd[i].sockfd);
  	 	 gl_fd[i].used=0;
  	 }
  }
}
